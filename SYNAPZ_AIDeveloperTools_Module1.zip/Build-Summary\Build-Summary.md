# SYNAPZ — Build Summary

**Innovation theme / partner track:** AI and Developer Tools — Sarvam Track  
**Official problem selection:** Why The Code Is Like This  
**Prototype:** CodeWhy

---

## Problem statement

Developers who inherit or modify unfamiliar code can observe what it does but often cannot reconstruct why it was structured that way. Before changing it, they must piece together context from tests, documentation, call sites, Git history, and teammates. CodeWhy provides a fast first-pass explanation that separates observable behaviour from inference and tells the developer what to verify next.

## How the problem evolved

The initial framing was "explain code." The final framing is narrower: help a developer understand unfamiliar code before making a change, explicitly label uncertain reasoning as inference, and surface concrete verification steps. This keeps the product honest and more useful — a fabricated explanation is worse than none.

## What was built

CodeWhy lets a user paste a focused code snippet, choose an explanation language (English or one of ten Indian languages), and request a Sarvam-105B explanation. The prompt instructs the model to separate observable behaviour from possible reasons labelled as inference, and to provide verification steps. The prototype does not modify code, index a full repository, or claim to know undocumented historical intent as fact.

## Technology

| Layer | Choice | Reason |
|---|---|---|
| Frontend | HTML / CSS / Vanilla JS | No build step; portable; easy to inspect |
| Backend | Node.js native HTTP server | No npm install required; minimal surface area |
| AI | Sarvam-105B via Chat Completions API | Required by track; 128K context suits code analysis |
| Storage | None | Not needed for Module 1 |

## API integration (verified against official docs, 24 Oct 2026)

- Endpoint: `POST https://api.sarvam.ai/v1/chat/completions`
- Auth: `api-subscription-key` header (preferred per Sarvam docs)
- Model: `sarvam-105b`
- Auth failures: HTTP 403 with `error.code = "invalid_api_key_error"` (handled explicitly)

## Evidence position

The implementation follows the official Sarvam API documentation. The following tests were observed locally in this session:

**Verified:**
- `node --check server.mjs` — syntax valid
- `GET /` — HTTP 200, correct HTML page
- `GET /health` — `{"status":"ok","apiKeyConfigured":true}` when key present
- `POST /api/explain` with empty code — HTTP 400 with clear message
- **Live Sarvam API call** — `POST /api/explain` with a real key and `def add(a, b): return a + b` returned HTTP 200; `sarvam-105b` returned a 2157-character structured explanation covering observable behaviour, control flow, dependencies, inferences, and verification steps

**Not verified:**
- `POST /api/explain` with no key configured — confirmed in a prior session (HTTP 503); not re-run in this session
- Explanation correctness or quality beyond the one test snippet
- Multilingual output quality
- Human usability or stranger-test outcomes

The claims that developers prefer multilingual explanations and that verification prompts reduce unsafe edits remain hypotheses. No interviews, stranger-test results, adoption numbers, or market-size figures are claimed.

## Credential handling

The API key is read server-side from `SARVAM_API_KEY` in a local `.env` file. No real key is included in this ZIP, the source code, or any documentation. `.env` is excluded by `.gitignore` and from the archive.

## What to do next

1. Run a stranger test with a developer who was not involved in building CodeWhy. Record task completion and feedback.
2. If the snippet-only flow proves useful, add repository evidence ingestion (tests, call sites, docs, Git history) and link model claims to those sources.

## Documentation

- Sarvam API docs: https://docs.sarvam.ai/
- Chat Completions reference: https://docs.sarvam.ai/api-reference/chat/chat-completions
- Authentication: https://docs.sarvam.ai/api-reference/authentication
