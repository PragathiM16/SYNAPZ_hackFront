# CodeWhy — SYNAPZ

**Track:** Sarvam Track  
**Problem statement:** Why The Code Is Like This

## What it does

Paste an unfamiliar code snippet, choose an explanation language, and click **Explain with Sarvam**. The local server calls Sarvam-105B and returns an explanation that separates what the code observably does from what is labelled as inference.

## Requirements

- Node.js 18 or later — download from https://nodejs.org/
- A Sarvam API key — generate one at https://dashboard.sarvam.ai/

## Setup and run (Windows)

1. Open a terminal (Command Prompt or PowerShell) in this `prototype` folder.

2. Copy `.env.example` to a new file named `.env`:
   ```
   copy .env.example .env
   ```

3. Open `.env` in Notepad and replace `your_sarvam_api_key_here` with your real key:
   ```
   SARVAM_API_KEY=paste_your_real_key_here
   PORT=3000
   ```
   Save and close the file. Keep `.env` private — it is excluded from ZIP and Git by `.gitignore`.

4. Start the server:
   ```
   npm start
   ```

5. Open your browser and go to: **http://localhost:3000**

6. Paste a code snippet, select a language, click **Explain with Sarvam**.

No `npm install` is required. The server uses only Node.js built-in modules.

## Configuration

| Variable | Required | Description |
|---|---|---|
| `SARVAM_API_KEY` | Yes | Your Sarvam API key from dashboard.sarvam.ai |
| `PORT` | No | Port to listen on (default: 3000) |

## API request parameters

The server sends the following to `POST https://api.sarvam.ai/v1/chat/completions`:

| Parameter | Value | Notes |
|---|---|---|
| `model` | `sarvam-105b` | 128K context; recommended for code analysis |
| `messages` | `[{role:"user", content:<prompt>}]` | Prompt includes code + language |
| `max_tokens` | `2048` | Max tokens for the visible reply |
| `temperature` | `0.2` | Focused, deterministic output |
| `reasoning_effort` | `null` | Disables internal chain-of-thought; ensures output goes to `content` |

Auth header: `api-subscription-key: <SARVAM_API_KEY>`. Only `choices[0].message.content` is returned to the user. Internal `reasoning_content` is never exposed.

## Error handling

| Situation | What you see |
|---|---|
| Empty input | "Paste a code snippet first." |
| Missing API key | Clear 503 error with setup instructions |
| Invalid API key | "Invalid Sarvam API key" with guidance |
| Rate limit hit | "Sarvam API rate limit reached. Try again shortly." |
| Network error | "Network error reaching Sarvam API" |
| Server not running | "Could not reach the local server" |

## Security

- The API key lives only in `prototype/.env` on your machine.
- `.env` is excluded from Git and from the submission ZIP.
- The browser never receives the API key.
- Never commit a real key to version control or include it in screenshots.

## Files

| File | Purpose |
|---|---|
| `index.html` | Browser UI |
| `server.mjs` | Node HTTP server + Sarvam API integration |
| `package.json` | Start script and Node version requirement |
| `.env.example` | Placeholder — copy to `.env` and add your key |
| `PROJECT_SPEC.md` | Product specification |

## Test status (24 Oct 2026)

**Verified — observed in this session:**
- `node --check server.mjs` — syntax valid
- `GET /` — HTTP 200, correct HTML page served
- `GET /health` — `{"status":"ok","apiKeyConfigured":true}` when key is present
- `POST /api/explain` with empty code — HTTP 400, `{"error":"Paste a code snippet first."}`
- **Live Sarvam API call** — `POST /api/explain` with a real key and `def add(a, b): return a + b` returned HTTP 200; `sarvam-105b` returned a 2157-character structured explanation covering observable behaviour, control flow, dependencies, inferences, and verification steps

**Not verified:**
- `POST /api/explain` with no key configured — not re-run in this session (confirmed in a prior session; expected HTTP 503)
- Multilingual explanation quality
- Stranger / usability testing

## Official documentation

- Sarvam API docs: https://docs.sarvam.ai/
- Chat Completions reference: https://docs.sarvam.ai/api-reference/chat/chat-completions
- Authentication: https://docs.sarvam.ai/api-reference/authentication
