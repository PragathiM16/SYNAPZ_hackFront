import http from "node:http";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.dirname(fileURLToPath(import.meta.url));

// Load .env without external deps; shell env vars take precedence
try {
  const envText = await readFile(path.join(root, ".env"), "utf8");
  for (const line of envText.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const sep = trimmed.indexOf("=");
    if (sep < 1) continue;
    const name = trimmed.slice(0, sep).trim();
    let value = trimmed.slice(sep + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (name && process.env[name] === undefined) process.env[name] = value;
  }
} catch (err) {
  if (err.code !== "ENOENT") throw err;
}

const PORT = Number(process.env.PORT) || 3000;
const ENDPOINT = "https://api.sarvam.ai/v1/chat/completions";

function send(res, status, body, type = "application/json") {
  res.writeHead(status, { "Content-Type": type, "Access-Control-Allow-Origin": "*" });
  res.end(body);
}

function buildPrompt(code, language) {
  return `You are CodeWhy. Explain the code below. Respond in ${language}.

Use these five sections:
1. What it does (observable facts only)
2. How the control/data flow works
3. Dependencies and assumptions
4. Possible reasons for unusual choices (label each as "inference")
5. What to verify before changing it

Keep explanations grounded. Do not invent the original author's intent.

Code:
\`\`\`
${code}
\`\`\``;
}

async function callSarvam(code, language) {
  const apiKey = process.env.SARVAM_API_KEY;
  if (!apiKey) {
    const e = new Error("SARVAM_API_KEY is not configured. Add it to prototype/.env.");
    e.statusCode = 503;
    throw e;
  }

  let response;
  try {
    response = await fetch(ENDPOINT, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "api-subscription-key": apiKey,
      },
      body: JSON.stringify({
        model: "sarvam-105b",
        messages: [{ role: "user", content: buildPrompt(code, language) }],
        max_tokens: 2048,
        temperature: 0.2,
        reasoning_effort: null,
      }),
    });
  } catch (netErr) {
    const e = new Error("Network error reaching Sarvam API: " + netErr.message);
    e.statusCode = 502;
    throw e;
  }

  const raw = await response.text();

  if (!response.ok) {
    let errMsg = `Sarvam API returned HTTP ${response.status}.`;
    try {
      const d = JSON.parse(raw);
      if (response.status === 403) {
        errMsg = d?.error?.code === "invalid_api_key_error"
          ? "Invalid Sarvam API key. Check SARVAM_API_KEY in your .env file."
          : `Sarvam API forbidden (${d?.error?.code || 403}). Check your key and quota.`;
      } else if (response.status === 429) {
        errMsg = "Sarvam API rate limit hit. Try again in a moment.";
      } else {
        errMsg = d?.error?.message || errMsg;
      }
    } catch { /* use default errMsg */ }
    const e = new Error(errMsg);
    e.statusCode = response.status === 429 ? 429 : 502;
    throw e;
  }

  let data;
  try { data = JSON.parse(raw); }
  catch {
    const e = new Error("Sarvam returned a non-JSON response.");
    e.statusCode = 502;
    throw e;
  }

  // Only use content — the user-facing reply.
  // reasoning_content is internal chain-of-thought and must never be shown to users.
  const text = data?.choices?.[0]?.message?.content;

  if (!text || text.trim().length === 0) {
    const e = new Error("Sarvam returned no explanation text. Try a shorter snippet.");
    e.statusCode = 502;
    throw e;
  }

  return text.trim();
}

const server = http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
    });
    return res.end();
  }

  if (req.url === "/api/explain" && req.method === "POST") {
    let body = "";
    req.on("data", chunk => (body += chunk));
    req.on("end", async () => {
      let parsed;
      try { parsed = JSON.parse(body); }
      catch { return send(res, 400, JSON.stringify({ error: "Invalid JSON body." })); }

      const { code, language = "English" } = parsed;
      if (!code || typeof code !== "string" || code.trim().length === 0)
        return send(res, 400, JSON.stringify({ error: "Paste a code snippet first." }));
      if (code.length > 30000)
        return send(res, 400, JSON.stringify({ error: "Code must be under 30,000 characters." }));

      try {
        const explanation = await callSarvam(code.trim(), language);
        send(res, 200, JSON.stringify({ explanation }));
      } catch (err) {
        send(res, err.statusCode || 500, JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  if (req.url === "/health" && req.method === "GET") {
    return send(res, 200, JSON.stringify({ status: "ok", apiKeyConfigured: !!process.env.SARVAM_API_KEY }));
  }

  if (req.method === "GET") {
    try {
      const html = await readFile(path.join(root, "index.html"));
      return send(res, 200, html, "text/html; charset=utf-8");
    } catch {
      return send(res, 404, JSON.stringify({ error: "Not found." }));
    }
  }

  send(res, 404, JSON.stringify({ error: "Not found." }));
});

server.listen(PORT, () => console.log(`CodeWhy running at http://localhost:${PORT}`));
